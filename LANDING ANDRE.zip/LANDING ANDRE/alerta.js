window.addEventListener('beforeunload', function (event) {
    const message = "Tem certeza de que deseja sair? As alterações não salvas podem ser perdidas.";

    // Configura a mensagem padrão para navegadores que suportam
    event.preventDefault();

    // Para alguns navegadores, a atribuição de event.returnValue ainda é necessária
    event.returnValue = message; 

    // Retorna a mensagem
    return message;
});
